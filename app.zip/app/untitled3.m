% Number of cities
N = 5;

% Distance matrix (randomly generated)
D = rand(N, N);
D = D + D'; % Make it symmetric
D(1:N+1:end) = Inf; % No self-loops

% Parameters
A = N * max(D(:)); % Scale parameter
B = 1; % Bias
C = N / 2; % Symmetry control
T = 1; % Temperature

% Initialization
U = zeros(N, N);
Y = rand(N, N); % Start with random values between 0 and 1

% Training
num_epochs = 1000;
learning_rate = 0.05;
for epoch = 1:num_epochs
    % Compute the dE/dY (gradient)
    dE_dY = A * (sum(Y, 1) + sum(Y, 2)' - ones(1, N)) + ...
            B * (sum(Y, 1)' * ones(1, N) + ones(N, 1) * sum(Y, 2)' - ones(N, N)) - ...
            C * D;
            
    % Update the states (sigmoid activation function)
    Y = Y - learning_rate * (dE_dY ./ (2 * T) - Y .* (1 - Y));
    
    % Apply constraints
    Y(1:N+1:end) = 0; % Diagonal is zero
    Y = min(max(Y, 0), 1); % Clamp between 0 and 1
    
    % Compute energy
    E = 0.5 * A * sum((sum(Y, 1) - 1).^2) + ...
        0.5 * B * sum((sum(Y, 2) - 1).^2) - ...
        0.5 * C * sum(sum(D .* Y));
        
    fprintf('Epoch %d: Energy = %.5f\n', epoch, E);
end

% Thresholding to binary values
Y(Y > 0.5) = 1;
Y(Y <= 0.5) = 0;

% Display the result
disp(Y);

% Verify the result (ensure that it is a valid TSP solution)
if all(sum(Y, 1) == 1) && all(sum(Y, 2) == 1)
    fprintf('Found a valid TSP solution.\n');
else
    fprintf('Did not find a valid TSP solution.\n');
end
