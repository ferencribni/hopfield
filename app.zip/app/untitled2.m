clc;
close all;

% Színes képek beolvasása és megjelenítése
% Beolvassuk a színes képeket és megjelenítjük őket egymás mellett.
kepek = {'petofi.jpg', 'pufi.jpg', 'feri.jpg', 'bill.jpg'};
figure(1000);
for i = 1:length(kepek)
    kep = imread(kepek{i});
    subplot(1,length(kepek),i);
    imshow(kep);
    title(['Kép ' num2str(i)]);
end

% Képek beolvasása és előfeldolgozása
% Minden képet beolvassunk, binarizálunk és kivágunk egy részét, majd
% kicsinyítjük őket. Végül összeállítjuk a képzési mintákat.
kep = imread('petofi.jpg');
ob = im2bw(kep);
ob1 = ob(1:900,300:1200);
ob2 = ob1(1:5:end-1,1:5:end);
meret_ob = size(ob2);

kep = imread('pufi.jpg');
tr = im2bw(kep);
tr1 = tr(50:1200,300:1500);
tr1 = imresize(tr1,[900,901]);
tr2 = tr1(1:5:end-1,1:5:end);

kep = imread('feri.jpg');
br = im2bw(kep);
br1 = imresize(br,[900,901]);
br2 = br1(1:5:end-1,1:5:end);

kep = imread('bill.jpg');
wr = im2bw(kep);
wr1 = wr(50:1230,298:end-500);
wr1 = imresize(wr1,[900,901]);
wr2 = wr1(1:5:end-1,1:5:end);

% Képzési minták megjelenítése
figure(155)
hold on
subplot(2,2,1); imshow(ob2); title('I. Képzési Mintázat');
subplot(2,2,2); imshow(tr2); title('II. Képzési Mintázat');
subplot(2,2,3); imshow(br2); title('III. Képzési Mintázat');
subplot(2,2,4); imshow(wr2); title('IV. Képzési Mintázat');

% Képzési minták előkészítése
P1 = real([reshape(ob2,meret_ob(1)*meret_ob(2),1) reshape(tr2,meret_ob(1)*meret_ob(2),1) ...
    reshape(br2,meret_ob(1)*meret_ob(2),1) reshape(wr2,meret_ob(1)*meret_ob(2),1)]);

% Képzési mátrix létrehozása
P_matrix = 2*P1 - 1;
W_matrix = P_matrix * P_matrix';

% Zajos képek generálása tesztadatokhoz
zajos_mintak = zajtcsinal(P_matrix);

% Hopfield hálózat tanítása
hibakuszob = 1;
kezdeti_allapot = zajos_mintak;
jelenlegi_allapot = kezdeti_allapot;

while hibakuszob > 0
    uj_allapot = jeleles2(W_matrix * jelenlegi_allapot);
    hibakuszob = max(abs(jelenlegi_allapot - uj_allapot));
    jelenlegi_allapot = uj_allapot;
end

% Különbség a bemeneti és kimeneti minták között
figure(555)
for i = 1:4
    kulonbseg = zajos_mintak(:,i) - jelenlegi_allapot(:,i);
    subplot(2, 2, i);
    plot(kulonbseg, 'LineWidth', 2);
    title(['Különbség a bemeneti és kimeneti minta között ' num2str(i)], 'FontSize', 16); % You can adjust the font size (e.g., 'FontSize', 16)
    xlabel('Pixel Index', 'FontSize', 14); % You can adjust the font size (e.g., 'FontSize', 14)
    ylabel('Különbség', 'FontSize', 14); % You can adjust the font size (e.g., 'FontSize', 14)
    ylim([-2, 2]);
end


% Zajos és kimeneti minták megjelenítése
figure(355)
subplot(2,4,1); imshow(reshape(zajos_mintak(:,1),meret_ob(1),meret_ob(2))); title('Zajos Mintázat');
subplot(2,4,2); imshow(reshape(jelenlegi_allapot(:,1),meret_ob(1),meret_ob(2))); title('Kimeneti Mintázat');
subplot(2,4,3); imshow(reshape(zajos_mintak(:,2),meret_ob(1),meret_ob(2))); title('Zajos Mintázat');
subplot(2,4,4); imshow(reshape(jelenlegi_allapot(:,2),meret_ob(1),meret_ob(2))); title('Kimeneti Mintázat');
subplot(2,4,5); imshow(reshape(zajos_mintak(:,3),meret_ob(1),meret_ob(2))); title('Zajos Mintázat');
subplot(2,4,6); imshow(reshape(jelenlegi_allapot(:,3),meret_ob(1),meret_ob(2))); title('Kimeneti Mintázat');
subplot(2,4,7); imshow(reshape(zajos_mintak(:,4),meret_ob(1),meret_ob(2))); title('Zajos Mintázat');
subplot(2,4,8); imshow(reshape(jelenlegi_allapot(:,4),meret_ob(1),meret_ob(2))); title('Kimeneti Mintázat');

return

% Zaj generálása a bemeneti mintákból
function PN = zajtcsinal(P)
r = rand(size(P));
PN = P;
for i = 1:4
    for j = 1:length(PN(:,i))
        if r(j,i) < .90
            PN(j,i) = 2*round(rand) - 1;
        end
    end
end
return
end

% Jelelési függvény
function ertek = jeleles2(x)
tmp = sign(x);
ertek = tmp + abs(tmp) - 1;
return
end
